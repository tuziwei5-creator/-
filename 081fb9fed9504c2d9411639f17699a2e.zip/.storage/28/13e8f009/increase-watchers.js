// This script increases the system's file watcher limit for the current session
// It's a workaround for the ENOSPC error in development mode

const { execSync } = require('child_process');

try {
  console.log('Attempting to increase file watcher limit...');
  
  // Increase the file watcher limit for the current session
  execSync('sysctl fs.inotify.max_user_watches=16384');
  console.log('Successfully increased file watcher limit to 16384');
  
  // Report the new limit
  const result = execSync('sysctl fs.inotify.max_user_watches').toString();
  console.log('Current setting:', result.trim());
  
  console.log('You can now run "pnpm run dev" without the ENOSPC error');
} catch (error) {
  console.error('Failed to increase file watcher limit:', error.message);
  console.log('Alternative solution: Try running "pnpm run dev -- --no-watch" to disable file watching');
}