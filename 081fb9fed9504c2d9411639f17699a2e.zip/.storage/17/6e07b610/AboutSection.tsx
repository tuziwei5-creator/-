import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";

export function AboutSection() {
  return (
    <section className="py-16 md:py-24 bg-black">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left column - Image */}
          <div className="relative">
            <div className="relative z-10 rounded-xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1604014056470-a33b4a67fe61?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
                alt="Luxury workshop"
                className="w-full h-[500px] object-cover"
              />
            </div>
            {/* Gold frame */}
            <div className="absolute -bottom-6 -right-6 w-full h-full border-2 border-gold-400 rounded-xl -z-10" />
          </div>
          
          {/* Right column - Content */}
          <div>
            <div className="inline-block rounded-full bg-gold-400/10 px-3 py-1 text-sm text-gold-400 mb-2">
              Our Story
            </div>
            <h2 className="text-3xl font-serif font-bold tracking-tighter text-white md:text-4xl mb-6">
              Craftsmanship Meets Luxury
            </h2>
            
            <div className="space-y-4 text-muted-foreground">
              <p>
                Since our founding in 1985, LUXE has been dedicated to the pursuit of perfection. Each of our products is meticulously crafted by skilled artisans using only the finest materials sourced from around the world.
              </p>
              <p>
                Our commitment to quality is unwavering. We believe that true luxury lies in the details - the perfect stitch, the precise cut, the immaculate finish. This dedication to craftsmanship has established LUXE as a beacon of excellence in the luxury market.
              </p>
              <p>
                Every LUXE product tells a story of heritage, innovation, and uncompromising standards. When you choose LUXE, you're not just acquiring a product; you're embracing a legacy of exceptional quality and timeless elegance.
              </p>
            </div>
            
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <Button 
                asChild 
                className="bg-gold-400 hover:bg-gold-500 text-black"
              >
                <Link to="/about">
                  Our Story
                </Link>
              </Button>
              <Button 
                variant="outline" 
                className="border-gold-400/30 text-gold-400 hover:bg-gold-900/20"
                asChild
              >
                <Link to="/craftsmanship">
                  Explore Craftsmanship <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
            
            {/* Signature */}
            <div className="mt-10 pt-6 border-t border-gold-400/20">
              <p className="text-white font-serif italic">"Excellence is not a matter of chance; it's a matter of choice."</p>
              <p className="text-gold-400 mt-1">- Marcus Laurent, Founder</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}