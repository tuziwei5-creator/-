import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";

interface ProductViewProps {
  productId: number;
  onClose: () => void;
}

export function ProductView({ productId, onClose }: ProductViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [startPosition, setStartPosition] = useState({ x: 0, y: 0 });
  const [autoRotate, setAutoRotate] = useState(true);

  // Handle auto rotation
  useEffect(() => {
    if (!autoRotate) return;
    
    const interval = setInterval(() => {
      setRotation(prev => ({ ...prev, y: prev.y + 0.5 }));
    }, 50);
    
    return () => clearInterval(interval);
  }, [autoRotate]);

  // Handle mouse/touch interactions
  const handleMouseDown = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    setAutoRotate(false);
    
    // Get the client position whether it's a touch or mouse event
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    
    setStartPosition({ x: clientX, y: clientY });
  };

  const handleMouseMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDragging) return;
    
    // Get the client position whether it's a touch or mouse event
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    
    const deltaX = clientX - startPosition.x;
    const deltaY = clientY - startPosition.y;
    
    setRotation(prev => ({
      x: prev.x + deltaY * 0.5,
      y: prev.y + deltaX * 0.5,
    }));
    
    setStartPosition({ x: clientX, y: clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div 
      ref={containerRef}
      className="w-full h-full flex items-center justify-center cursor-grab active:cursor-grabbing"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleMouseDown}
      onTouchMove={handleMouseMove}
      onTouchEnd={handleMouseUp}
    >
      <motion.div
        style={{
          rotateX: rotation.x,
          rotateY: rotation.y,
          transformStyle: "preserve-3d",
        }}
        className="w-64 h-64 relative"
      >
        {/* This would typically be replaced with a proper 3D model */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-gradient-to-br from-gold-300 to-gold-600 w-32 h-32 rounded-xl shadow-xl flex items-center justify-center">
            <span className="text-black font-bold">Product {productId}</span>
          </div>
        </div>
      </motion.div>
      
      <div className="absolute bottom-6 left-0 right-0 flex justify-center space-x-4">
        <button 
          onClick={() => setAutoRotate(!autoRotate)}
          className={`px-4 py-2 rounded-md text-sm ${
            autoRotate 
              ? "bg-gold-400 text-black" 
              : "bg-white/10 text-white"
          }`}
        >
          {autoRotate ? "Stop Rotation" : "Auto Rotate"}
        </button>
        <button 
          onClick={() => setRotation({ x: 0, y: 0 })}
          className="px-4 py-2 rounded-md text-sm bg-white/10 text-white"
        >
          Reset View
        </button>
      </div>
    </div>
  );
}