import { Link } from "react-router-dom";
import { Facebook, Instagram, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Footer() {
  return (
    <footer className="bg-black text-white border-t border-gold-400/20">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-serif font-bold text-gold-400">LUXE</h3>
            <p className="text-sm text-muted-foreground">
              Indulge in luxury with our exclusive collection of premium products crafted with meticulous attention to detail.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-white hover:bg-gold-900/20 rounded-full">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-gold-900/20 rounded-full">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-gold-900/20 rounded-full">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Button>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-medium text-gold-400">Shop</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/category/bags" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Bags
                </Link>
              </li>
              <li>
                <Link to="/category/clothing" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Clothing
                </Link>
              </li>
              <li>
                <Link to="/category/shoes" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Shoes
                </Link>
              </li>
              <li>
                <Link to="/category/watches" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Watches
                </Link>
              </li>
              <li>
                <Link to="/category/jewelry" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Jewelry
                </Link>
              </li>
            </ul>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-medium text-gold-400">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/stores" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Store Locations
                </Link>
              </li>
              <li>
                <Link to="/careers" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Careers
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-medium text-gold-400">Subscribe</h3>
            <p className="text-sm text-muted-foreground">Subscribe to our newsletter for exclusive updates and offers.</p>
            <div className="flex space-x-2">
              <Input
                type="email"
                placeholder="Your email"
                className="bg-black border-gold-400/30 focus-visible:ring-gold-400"
              />
              <Button variant="outline" className="border-gold-400 text-gold-400 hover:bg-gold-900/20">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gold-400/10 text-sm text-muted-foreground">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <p>&copy; {new Date().getFullYear()} LUXE. All rights reserved.</p>
            <div className="flex space-x-6">
              <Link to="/privacy" className="hover:text-gold-400 transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="hover:text-gold-400 transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}