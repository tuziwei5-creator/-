import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";

const heroImages = [
  {
    url: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80",
    category: "bags",
    title: "Signature Collection",
    description: "Discover our exclusive line of luxury bags crafted with precision and elegance."
  },
  {
    url: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1587&q=80",
    category: "clothing",
    title: "Premium Apparel",
    description: "Elevate your style with our meticulously crafted clothing line."
  },
  {
    url: "https://images.unsplash.com/photo-1551816230-ef5deaed4a26?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1665&q=80",
    category: "watches",
    title: "Timeless Watches",
    description: "Precision engineering meets stunning design in our luxury timepiece collection."
  }
];

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative h-[70vh] md:h-[85vh] overflow-hidden">
      {/* Slides */}
      <div className="relative h-full">
        {heroImages.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentSlide ? "opacity-100" : "opacity-0"
            }`}
          >
            {/* Image overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black" />
            
            {/* Background image */}
            <div 
              className="w-full h-full bg-cover bg-center"
              style={{ backgroundImage: `url(${slide.url})` }}
            />
            
            {/* Content */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="container px-4 md:px-6 flex flex-col items-center text-center z-10 space-y-6">
                <div className="space-y-2 animate-in fade-in slide-in-from-bottom-4 duration-1000">
                  <p className="text-gold-400 font-medium uppercase tracking-wider">
                    {slide.category}
                  </p>
                  <h1 className="text-3xl md:text-5xl lg:text-6xl font-serif font-bold text-white max-w-3xl">
                    {slide.title}
                  </h1>
                  <p className="text-white/80 max-w-[42rem] md:text-lg">
                    {slide.description}
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 animate-in fade-in slide-in-from-bottom-4 delay-300 duration-1000">
                  <Button 
                    asChild 
                    className="bg-gold-400 hover:bg-gold-500 text-black"
                  >
                    <Link to={`/category/${slide.category}`}>
                      Explore Collection
                    </Link>
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-white text-white hover:bg-white/10"
                    asChild
                  >
                    <Link to="/vip">
                      VIP Reservation <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Slide indicators */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {heroImages.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentSlide 
                ? "bg-gold-400 w-8" 
                : "bg-white/50 hover:bg-white/70"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
}