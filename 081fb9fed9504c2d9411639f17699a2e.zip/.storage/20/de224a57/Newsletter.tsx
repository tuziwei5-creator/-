import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle, Mail } from "lucide-react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) return;
    
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setIsSubmitted(true);
      setEmail("");
      
      // Reset success state after 3 seconds
      setTimeout(() => setIsSubmitted(false), 3000);
    }, 1000);
  };

  return (
    <section className="py-16 md:py-24 bg-black">
      <div className="container px-4 md:px-6">
        <div className="w-full max-w-6xl mx-auto">
          <div className="bg-gradient-to-b from-black to-black/95 border border-gold-400/20 rounded-xl p-8 md:p-12 relative overflow-hidden">
            {/* Gold decorative element */}
            <div className="absolute top-0 left-0 w-32 h-32 rounded-br-[100px] bg-gradient-to-br from-gold-400/20 to-gold-400/5 -z-10" />
            <div className="absolute bottom-0 right-0 w-32 h-32 rounded-tl-[100px] bg-gradient-to-br from-gold-400/5 to-gold-400/20 -z-10" />
            
            <div className="flex flex-col items-center text-center max-w-3xl mx-auto relative z-10">
              <div className="w-14 h-14 rounded-full bg-gold-400/10 flex items-center justify-center mb-6">
                <Mail className="h-6 w-6 text-gold-400" />
              </div>
              
              <h2 className="text-3xl font-serif font-bold tracking-tighter text-white md:text-4xl mb-4">
                Join Our Exclusive Circle
              </h2>
              
              <p className="text-muted-foreground md:text-lg mb-8">
                Subscribe to receive early access to new collections, private event invitations, and curated content tailored to your luxury lifestyle.
              </p>
              
              {isSubmitted ? (
                <div className="flex items-center justify-center space-x-2 text-gold-400 animate-in fade-in slide-in-from-bottom-4 duration-300">
                  <CheckCircle className="h-5 w-5" />
                  <span>Thank you for subscribing</span>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="w-full space-y-4">
                  <div className="flex flex-col sm:flex-row gap-3 w-full">
                    <div className="relative flex-grow">
                      <Input
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="bg-black/40 border-gold-400/30 focus:border-gold-400 h-12 pl-10"
                      />
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gold-400/50" />
                    </div>
                    <Button 
                      type="submit" 
                      className="bg-gold-400 hover:bg-gold-500 text-black h-12 px-6"
                      disabled={isLoading}
                    >
                      {isLoading ? "Subscribing..." : "Subscribe"}
                    </Button>
                  </div>
                  
                  <p className="text-sm text-muted-foreground">
                    By subscribing, you agree to our Privacy Policy and consent to receive news from LUXE.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}