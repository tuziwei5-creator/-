import { useEffect, useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { HeroSection } from "@/components/HeroSection";
import { FeaturedProducts } from "@/components/FeaturedProducts";
import { Categories } from "@/components/Categories";
import { AboutSection } from "@/components/AboutSection";
import { VIPReservation } from "@/components/VIPReservation";
import { Testimonials } from "@/components/Testimonials";
import { Newsletter } from "@/components/Newsletter";

export default function HomePage() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading for a smoother transition
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="animate-pulse">
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-gold-400">LUXE</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main className="flex flex-col">
        <HeroSection />
        <Categories />
        <FeaturedProducts />
        <AboutSection />
        <Testimonials />
        <VIPReservation />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}
