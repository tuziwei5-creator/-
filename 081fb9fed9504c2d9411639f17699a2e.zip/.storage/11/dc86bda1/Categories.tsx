import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const categories = [
  {
    name: "Bags",
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=735&q=80",
    href: "/category/bags"
  },
  {
    name: "Clothing",
    image: "https://images.unsplash.com/photo-1543076447-215ad9ba6923?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1074&q=80",
    href: "/category/clothing"
  },
  {
    name: "Shoes",
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
    href: "/category/shoes"
  },
  {
    name: "Watches",
    image: "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=694&q=80",
    href: "/category/watches"
  },
  {
    name: "Jewelry",
    image: "https://images.unsplash.com/photo-1599643477877-530eb83abc8e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
    href: "/category/jewelry"
  }
];

export function Categories() {
  return (
    <section className="py-16 md:py-24 bg-black">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center mb-12">
          <div className="inline-block rounded-full bg-gold-400/10 px-3 py-1 text-sm text-gold-400 mb-2">
            Categories
          </div>
          <h2 className="text-3xl font-serif font-bold tracking-tighter text-white md:text-4xl">
            Explore Our Collections
          </h2>
          <p className="max-w-[700px] text-muted-foreground md:text-lg">
            Discover our curated categories of premium luxury products crafted with excellence and sophistication.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => (
            <Link 
              key={index}
              to={category.href}
              className="group relative overflow-hidden rounded-lg h-[300px]"
            >
              {/* Overlay */}
              <div className="absolute inset-0 bg-black/50 group-hover:bg-black/40 transition-colors duration-300 z-10" />
              
              {/* Background Image */}
              <img 
                src={category.image}
                alt={category.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              
              {/* Content */}
              <div className="absolute inset-0 flex items-center justify-center z-20">
                <div className="text-center">
                  <h3 className="text-2xl font-serif font-bold text-white mb-2">{category.name}</h3>
                  <div className="w-10 h-0.5 bg-gold-400 mx-auto transform origin-center scale-0 group-hover:scale-100 transition-transform duration-300" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}