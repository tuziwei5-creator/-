import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, CheckCircle } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";

// Form schema
const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Please enter a valid phone number." }),
  date: z.date({
    required_error: "Please select a date for your appointment.",
  }),
  time: z.string({
    required_error: "Please select a time for your appointment.",
  }),
  location: z.string({
    required_error: "Please select a boutique location.",
  }),
  interests: z.string().min(1, { message: "Please select your interests." }),
  message: z.string().optional(),
});

const locations = [
  { value: "new-york", label: "New York" },
  { value: "london", label: "London" },
  { value: "paris", label: "Paris" },
  { value: "tokyo", label: "Tokyo" },
  { value: "dubai", label: "Dubai" },
];

const interests = [
  { value: "bags", label: "Bags & Accessories" },
  { value: "clothing", label: "Clothing" },
  { value: "shoes", label: "Shoes" },
  { value: "watches", label: "Watches" },
  { value: "jewelry", label: "Jewelry" },
];

const availableTimes = [
  "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
  "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM",
  "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM",
  "4:00 PM", "4:30 PM", "5:00 PM", "5:30 PM",
];

export function VIPReservation() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    // In a real app, you would submit this data to your backend
    console.log(values);
    
    // Show success state
    setIsSubmitted(true);
    
    // Reset after 3 seconds in this demo (would typically navigate elsewhere)
    setTimeout(() => {
      setIsSubmitted(false);
      form.reset();
    }, 5000);
  }

  return (
    <section className="py-16 md:py-24 bg-black">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center mb-12">
          <div className="inline-block rounded-full bg-gold-400/10 px-3 py-1 text-sm text-gold-400 mb-2">
            Exclusive Experience
          </div>
          <h2 className="text-3xl font-serif font-bold tracking-tighter text-white md:text-4xl">
            VIP Reservation
          </h2>
          <p className="max-w-[700px] text-muted-foreground md:text-lg">
            Schedule a private appointment with our luxury consultants for a personalized shopping experience.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
          {/* Left column - Benefits */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-black/40 border border-gold-400/20 rounded-xl p-6 space-y-6">
              <h3 className="text-xl font-serif font-semibold text-white">The VIP Experience</h3>
              
              <div className="space-y-4">
                {[
                  {
                    title: "Personal Stylist",
                    description: "Work with our experienced stylists who understand your preferences and lifestyle.",
                  },
                  {
                    title: "Private Viewing Room",
                    description: "Enjoy our collections in the comfort and privacy of our exclusive viewing suites.",
                  },
                  {
                    title: "Pre-Launch Access",
                    description: "Be among the first to view and purchase our newest collections before public release.",
                  },
                  {
                    title: "Bespoke Services",
                    description: "Discover our customization options to create truly one-of-a-kind pieces.",
                  },
                  {
                    title: "Refreshments",
                    description: "Indulge in fine champagne and gourmet refreshments during your appointment.",
                  },
                ].map((benefit, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-6 w-6 text-gold-400">
                      <CheckCircle className="h-6 w-6" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">{benefit.title}</h4>
                      <p className="text-sm text-muted-foreground">{benefit.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-black/40 border border-gold-400/20 rounded-xl p-6">
              <h3 className="text-xl font-serif font-semibold text-white mb-4">Contact Us Directly</h3>
              <p className="text-muted-foreground mb-4">
                For immediate assistance or to speak with our VIP relations team:
              </p>
              <div className="space-y-2">
                <p className="text-white">Call: <span className="text-gold-400">+1 (800) 555-LUXE</span></p>
                <p className="text-white">Email: <span className="text-gold-400">vip@luxe.example</span></p>
              </div>
            </div>
          </div>

          {/* Right column - Form */}
          <div className="lg:col-span-3 relative">
            {isSubmitted ? (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-black/40 border border-gold-400/20 rounded-xl p-8 text-center h-full flex flex-col items-center justify-center"
              >
                <div className="w-16 h-16 bg-gold-400/10 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="h-8 w-8 text-gold-400" />
                </div>
                <h3 className="text-2xl font-serif font-semibold text-white mb-2">
                  Reservation Confirmed
                </h3>
                <p className="text-muted-foreground max-w-md mb-6">
                  Thank you for your reservation. Our VIP concierge team will contact you shortly to confirm your appointment details.
                </p>
                <Button
                  variant="outline"
                  className="border-gold-400/30 text-gold-400 hover:bg-gold-900/20"
                  onClick={() => setIsSubmitted(false)}
                >
                  Make Another Reservation
                </Button>
              </motion.div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-black/40 border border-gold-400/20 rounded-xl p-6 lg:p-8"
              >
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your name" className="bg-black/40 border-gold-400/30 focus:border-gold-400" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Email</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="Enter your email" className="bg-black/40 border-gold-400/30 focus:border-gold-400" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="+1 (555) 555-5555" className="bg-black/40 border-gold-400/30 focus:border-gold-400" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Boutique Location</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-black/40 border-gold-400/30 focus:border-gold-400">
                                  <SelectValue placeholder="Select location" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-black border border-gold-400/30">
                                {locations.map((location) => (
                                  <SelectItem key={location.value} value={location.value} className="focus:bg-gold-400/20 focus:text-gold-400">
                                    {location.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel className="text-white">Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className="bg-black/40 border-gold-400/30 focus:border-gold-400 text-left font-normal h-10"
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span className="text-muted-foreground">Select date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0 bg-black border border-gold-400/30" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date < new Date()}
                                  initialFocus
                                  className="bg-black"
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="time"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Time</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-black/40 border-gold-400/30 focus:border-gold-400">
                                  <SelectValue placeholder="Select time" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-black border border-gold-400/30 max-h-[200px]">
                                {availableTimes.map((time) => (
                                  <SelectItem key={time} value={time} className="focus:bg-gold-400/20 focus:text-gold-400">
                                    {time}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="interests"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Primary Interest</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-black/40 border-gold-400/30 focus:border-gold-400">
                                <SelectValue placeholder="Select your primary interest" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-black border border-gold-400/30">
                              {interests.map((interest) => (
                                <SelectItem key={interest.value} value={interest.value} className="focus:bg-gold-400/20 focus:text-gold-400">
                                  {interest.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Special Requests</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Please share any special requests or items you're particularly interested in viewing"
                              className="bg-black/40 border-gold-400/30 focus:border-gold-400 resize-none"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription className="text-muted-foreground">
                            Your personal shopper will prepare based on your preferences.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-gold-400 hover:bg-gold-500 text-black"
                    >
                      Request Appointment
                    </Button>
                  </form>
                </Form>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}