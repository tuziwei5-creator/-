import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ProductView } from "./ProductView";

// Sample product data
const products = [
  {
    id: 1,
    name: "Signature Tote Bag",
    category: "bags",
    price: 1250,
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=735&q=80",
    isNew: true,
    hasModel: true,
  },
  {
    id: 2,
    name: "Elite Chronograph Watch",
    category: "watches",
    price: 8750,
    image: "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=694&q=80",
    isNew: false,
    hasModel: true,
  },
  {
    id: 3,
    name: "Premium Leather Boots",
    category: "shoes",
    price: 895,
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
    isNew: true,
    hasModel: false,
  },
  {
    id: 4,
    name: "Cashmere Sweater",
    category: "clothing",
    price: 780,
    image: "https://images.unsplash.com/photo-1543076447-215ad9ba6923?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1074&q=80",
    isNew: false,
    hasModel: false,
  },
];

export function FeaturedProducts() {
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);
  const [showingProduct, setShowingProduct] = useState(false);

  const handleProductClick = (productId: number) => {
    if (products.find(p => p.id === productId)?.hasModel) {
      setSelectedProduct(productId);
      setShowingProduct(true);
    }
  };

  const closeProductView = () => {
    setShowingProduct(false);
    setTimeout(() => setSelectedProduct(null), 300); // Wait for animation to complete
  };

  return (
    <>
      <section className="py-16 md:py-24 bg-black">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <div className="inline-block rounded-full bg-gold-400/10 px-3 py-1 text-sm text-gold-400 mb-2">
                Featured
              </div>
              <h2 className="text-3xl font-serif font-bold tracking-tighter text-white md:text-4xl">
                New Arrivals
              </h2>
              <p className="mt-2 max-w-[700px] text-muted-foreground md:text-lg">
                Discover our latest collection of premium luxury products.
              </p>
            </div>
            <div className="flex space-x-2 mt-4 md:mt-0">
              <Button 
                variant="outline" 
                size="icon" 
                className="border-gold-400/30 text-gold-400 hover:bg-gold-900/20"
              >
                <ChevronLeft className="h-4 w-4" />
                <span className="sr-only">Previous</span>
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="border-gold-400/30 text-gold-400 hover:bg-gold-900/20"
              >
                <ChevronRight className="h-4 w-4" />
                <span className="sr-only">Next</span>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <motion.div
                key={product.id}
                whileHover={{ y: -5 }}
                transition={{ duration: 0.2 }}
                className="group relative bg-black rounded-lg overflow-hidden"
              >
                <div className="relative aspect-square overflow-hidden">
                  {/* Product image */}
                  <img
                    src={product.image}
                    alt={product.name}
                    className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-110"
                  />
                  
                  {/* Quick view overlay for 3D products */}
                  {product.hasModel && (
                    <div 
                      className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                      onClick={() => handleProductClick(product.id)}
                    >
                      <Button 
                        variant="outline" 
                        className="border-white text-white hover:bg-white/20"
                      >
                        View in 3D
                      </Button>
                    </div>
                  )}
                  
                  {/* New badge */}
                  {product.isNew && (
                    <Badge 
                      className="absolute top-2 right-2 bg-gold-400 text-black hover:bg-gold-500"
                    >
                      New
                    </Badge>
                  )}
                </div>
                
                <div className="p-4">
                  <h3 className="font-medium text-white mb-1">{product.name}</h3>
                  <p className="text-gold-400 font-semibold">${product.price.toLocaleString()}</p>
                </div>
                
                <Link 
                  to={`/product/${product.id}`}
                  className="absolute inset-0 z-10"
                  aria-label={`View ${product.name}`}
                />
              </motion.div>
            ))}
          </div>
          
          <div className="flex justify-center mt-10">
            <Button 
              asChild
              className="bg-gold-400 hover:bg-gold-500 text-black"
            >
              <Link to="/collections">
                View All Collections
              </Link>
            </Button>
          </div>
        </div>
      </section>
      
      {/* 3D Product Viewer Modal */}
      {selectedProduct && (
        <div 
          className={`fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 transition-opacity duration-300 ${
            showingProduct ? "opacity-100" : "opacity-0"
          }`}
        >
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative bg-black/80 rounded-xl overflow-hidden border border-gold-400/20 w-full max-w-4xl aspect-[4/3]"
          >
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-4 right-4 z-10 text-white bg-black/20 hover:bg-black/40"
              onClick={closeProductView}
            >
              <ChevronRight className="h-5 w-5 rotate-45" />
              <span className="sr-only">Close</span>
            </Button>
            
            {/* This would typically be a 3D viewer component */}
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-b from-black/0 to-black/40">
              <p className="text-white text-center">
                3D Product Viewer Would Be Implemented Here<br />
                <span className="text-sm text-white/60">
                  Using Three.js / React Three Fiber
                </span>
              </p>
            </div>
          </motion.div>
        </div>
      )}
    </>
  );
}