import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

// Sample testimonial data
const testimonials = [
  {
    id: 1,
    content: "The craftsmanship on my custom leather bag is impeccable. Every detail has been meticulously considered, from the stitching to the hardware. It's a true testament to LUXE's commitment to quality.",
    author: "Isabella Montgomery",
    title: "Fashion Editor, Vogue",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
    rating: 5,
  },
  {
    id: 2,
    content: "My LUXE chronograph watch has become my most treasured possession. The blend of innovative technology and traditional watchmaking is extraordinary. It's not just a timepiece; it's a legacy.",
    author: "Alexander Chen",
    title: "CEO, Quantum Technologies",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
    rating: 5,
  },
  {
    id: 3,
    content: "The VIP shopping experience at LUXE was beyond compare. The personal attention, the private viewing room, and the curated selection tailored to my preferences made me feel truly special.",
    author: "Sophia Laurent",
    title: "Philanthropist",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=688&q=80",
    rating: 5,
  },
  {
    id: 4,
    content: "As someone who appreciates fine craftsmanship, I can say with confidence that LUXE's attention to detail is unrivaled. My cashmere coat is not only beautiful but built to last for generations.",
    author: "James Harrington",
    title: "Architect",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
    rating: 4,
  },
];

export function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0);
  
  const handlePrevious = () => {
    setActiveIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };
  
  const handleNext = () => {
    setActiveIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-black to-black/95">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center mb-12">
          <div className="inline-block rounded-full bg-gold-400/10 px-3 py-1 text-sm text-gold-400 mb-2">
            Testimonials
          </div>
          <h2 className="text-3xl font-serif font-bold tracking-tighter text-white md:text-4xl">
            What Our Clients Say
          </h2>
          <p className="max-w-[700px] text-muted-foreground md:text-lg">
            Discover the experiences of our distinguished clientele with our luxury products and services.
          </p>
        </div>

        <div className="relative overflow-hidden">
          <div 
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${activeIndex * 100}%)` }}
          >
            {testimonials.map((testimonial) => (
              <div 
                key={testimonial.id}
                className="w-full flex-shrink-0 px-4 md:px-12"
              >
                <div className="bg-black/40 border border-gold-400/20 rounded-xl p-8 md:p-10 flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-gold-400 mb-6">
                    <img
                      src={testimonial.image}
                      alt={testimonial.author}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="mb-6 text-gold-400">
                    <Quote className="h-8 w-8 mx-auto opacity-60" />
                  </div>
                  
                  <blockquote className="text-lg md:text-xl text-white italic mb-6 max-w-3xl">
                    "{testimonial.content}"
                  </blockquote>
                  
                  <div className="flex justify-center mb-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <svg
                        key={i}
                        className={`w-5 h-5 ${
                          i < testimonial.rating ? "text-gold-400" : "text-gray-400"
                        }`}
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  
                  <div>
                    <h4 className="font-serif font-bold text-white text-lg">
                      {testimonial.author}
                    </h4>
                    <p className="text-muted-foreground">{testimonial.title}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Navigation */}
          <div className="flex justify-center mt-8 space-x-2">
            <Button 
              variant="outline" 
              size="icon" 
              className="border-gold-400/30 text-gold-400 hover:bg-gold-900/20 rounded-full"
              onClick={handlePrevious}
            >
              <ChevronLeft className="h-5 w-5" />
              <span className="sr-only">Previous</span>
            </Button>
            
            <div className="flex items-center space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    activeIndex === index ? "bg-gold-400" : "bg-gold-400/30"
                  }`}
                  onClick={() => setActiveIndex(index)}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            
            <Button 
              variant="outline" 
              size="icon" 
              className="border-gold-400/30 text-gold-400 hover:bg-gold-900/20 rounded-full"
              onClick={handleNext}
            >
              <ChevronRight className="h-5 w-5" />
              <span className="sr-only">Next</span>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}